# IoT-Forum-Project

2 lane traffic managment project. using YOLO , opencv and raspberryPi. 
